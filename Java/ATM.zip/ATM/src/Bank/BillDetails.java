package Bank;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class BillDetails{

	private int id;
	private int billid;
	private BigDecimal balance;
	private String datetime;
	
	public BillDetails() {
		
	}

	public BillDetails(int id, int billid, BigDecimal balance, String datetime) {
		super();
		this.id = id;
		this.billid = billid;
		this.balance = balance;
		this.datetime = datetime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBillid() {
		return billid;
	}

	public void setBillid(int billid) {
		this.billid = billid;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	@Override
	public String toString() {
		return "BillDetails [id=" + id + ", billid=" + billid + ", balance=" + balance + ", datetime=" + datetime + "]";
	}

	public static void main(String[] args) {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		BillDetails b = new BillDetails();
		
		b.setDatetime(df.format(new Date(new java.util.Date().getTime()))); 
		
		System.out.println(b.getDatetime());
	}
	
}
