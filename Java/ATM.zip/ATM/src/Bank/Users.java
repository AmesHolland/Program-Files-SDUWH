package Bank;

import java.math.BigDecimal;
import java.util.Scanner;

public class Users {
	
	private String CardId;
	private String PassWord;
	private String Name;
	private BigDecimal Balance;
	
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public String getCardId() {
		return CardId;
	}

	public void setCardId(String cardId) {
		CardId = cardId;
	}

	public BigDecimal getBalance() {
		return Balance;
	}

	public void setBalance(BigDecimal balance) {
		Balance = balance;
	}

	public Users(String cardid,String password, String name, BigDecimal balance) {
		
		this.CardId = cardid;
		this.PassWord = password;
		this.Name = name;
		this.Balance  = balance;
		
	}
}
