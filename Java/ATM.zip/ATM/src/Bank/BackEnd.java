package Bank;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public interface BackEnd {

	public void InitBill(String cardid) ;
	public boolean LoginVer(String cardid, String password);
	public BigDecimal Inquiry(String cardid);
	public void Save(BigDecimal n) ;
	public void Take(BigDecimal n ) ;
	public boolean Judge(BigDecimal n) ;
	public ResultSet PayMents() ;
	
}
