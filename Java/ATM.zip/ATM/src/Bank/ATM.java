package Bank;

public class ATM {

	private ATM_BackEnd ab;
	private ATM_FrontEnd af;
	
	
	public ATM() {
		
		this.ab = new ATM_BackEnd();
		this.af = new ATM_FrontEnd(this.ab);
		
	}
	
	public void Run() {
		
		af.Run();
		
	}
	
}
