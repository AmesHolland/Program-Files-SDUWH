package Bank;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQL {
	
	private static final String driverName = "com.mysql.cj.jdbc.Driver";
	private static final String dbURL = "jdbc:mysql://localhost:3306/bank?useSSL=false&allowPublicKeyRetrieval=true";
	private static final String userName = "root";
	private static final String userPwd = "root";
	
	private static Connection conn = null;
	private static Statement stmt = null;
	public static ResultSet rs = null;

	public SQL() {
		
		conn = connectDatabase();
		// TODO Auto-generated constructor stub
	}
	
	public static Connection connectDatabase() {
		
		Connection dbConn = null;
		
		try
		{

			Class.forName(driverName);
			dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
			System.out.println("连接数据库成功");

		}
		catch (Exception e)
		{

			e.printStackTrace();
			System.out.print("连接失败");

		}	
		
		return dbConn;
		
	}
	
	public ResultSet search(String sql) {
		
		if( null != conn) {
			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		return rs;		
	}
	
	public void update(String sql){
		
		if(conn != null) {
			try {
				stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				System.out.println("修改成功");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
	}
	public void close() {
		
		if(stmt == null || rs == null) {
			System.out.println("数据库未进行任何操作");
		}
		else {
			try {
				stmt.close();
				conn.close();
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("数据库关闭成功");
		}
	}
}