package Bank;

import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;

public class ATM_BackEnd  implements BackEnd{

	private SQL sql;
	private int BillId;
	private Users user;
	
	
	public SQL getSql() {
		return sql;
	}

	public void setSql(SQL sql) {
		this.sql = sql;
	}

	public int getBillId() {
		return BillId;
	}

	public void setBillId(int billId) {
		BillId = billId;
	}
	
	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}


	public ATM_BackEnd() {
		super();
		sql = new SQL();
		// TODO Auto-generated constructor stub
	}

	@Override  //Initial Billing 初始化账单
	public void InitBill(String cardid) {
			
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = new String(df.format(new Date(new java.util.Date().getTime())));
	
		
		/*
		 * Only the bill creation time and user card number are inserted here 
		 * because the billid is self-incremented by the database 数据库自增实现无需手动添加
		 */		
		sql.update("insert into bill (账单创建时间, 用户卡号) values (\'" + time + "\',\'"+ cardid +"\')");
		
		/* Select the billid just generated as the billid for the new bill */
		
		ResultSet rs = sql.search("select 账单号 from bill order by 账单号 desc limit 1");
		try {
			if(rs.next()) {
				this.setBillId(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override //Login Verification,return verification results
	public boolean LoginVer(String cardid, String password){
		
		String s = new String("select * from users where users.卡号 = \'" + cardid + "\' and users.密码 = \'" + password+"\'");
		
		ResultSet rs = sql.search(s);
		
		try {
			/* If the user information can be looked up */
			if(rs.next()) {
				try {					
						
						String s1 = rs.getString("卡号");
						String s2 = rs.getString("密码");
						
						if(s1.equals(cardid) && s2.equals(password)) {		
							InitBill(cardid);
							/* User's default constructor */							
							user = new Users(rs.getString("卡号"),rs.getString("密码"), rs.getString("姓名"), rs.getBigDecimal("余额"));
							
							return true;
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					    
					}
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* If the user information is not available return false */
		return false;
	}
	
	@Override //Inquiring the balance,return query information
	public BigDecimal Inquiry(String cardid) {
		
		String s = new String("select 余额 from users where users.卡号 = \'" + cardid + "\'");

		ResultSet rs = sql.search(s);
		
		BigDecimal n = new BigDecimal(0);
		
		try {
			if(rs.next()) {
				n = rs.getBigDecimal("余额");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return n;
	}
	
	@Override //Saving money
	public void Save(BigDecimal n) {
		
		//Maintaining data consistency for 'user'
		user.setBalance(user.getBalance().add(n));
		sql.update("update users set 余额 = 余额 + " + n + " where 卡号 = \'"+ this.getUser().getCardId() + "\'");
	}
	
	@Override //Taking money
	public void Take(BigDecimal n ) {
		
		//Maintaining data consistency for 'users'
		user.setBalance(user.getBalance().add(n));
		sql.update("update users set 余额 = 余额 + " + n + " where 卡号 = \'"+ this.getUser().getCardId() + "\'");
		
	}
	
	@Override 
	/*
	 * Determining whether a user 
	 * 	can take money 
	 *  return the result
	 */
	public boolean Judge(BigDecimal n) {
		
		
		if(n.compareTo(user.getBalance()) == 1 ) {
			return false;
		}
		
		//Get the current date
		Date date = new Date(new java.util.Date().getTime());
		
		String s = new String("select sum(收支) 总计取钱 "
        + "from billdetails join bill on billdetails.账单号 = bill.账单号 "
        + "where 收支 < 0 and 用户卡号 = \'" + this.getUser().getCardId() + "\' and DATE(处理时间) = \'" + date + "\'"
        + " group by DATE(处理时间) ");
		
		//System.out.println(s);
		
		ResultSet rs = sql.search(s);
		/*
		 * Set the maximum 
		 * number of withdrawals 
		 * for the day
		 */
		BigDecimal max =  new BigDecimal(10000);
		BigDecimal b = new BigDecimal(0);
		
		try {
			if(rs.next()) {
				/*
				 * The money taken out 
				 * is stored in the database 
				 * as a negative number, 
				 * which needs to be inverted and 
				 * compared with the maximum amount
				 */				
				b = rs.getBigDecimal("总计取钱").negate();
				b = b.add(n);
				if(b.compareTo(max) == 1) {
					return false; 
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
		
	}

	@Override 
	public ResultSet PayMents() {
		
		
		/*
		 * Return the top 20 resultset of the most 
		 * recent take and save
		 */
		String s = "select * from billdetails join bill on billdetails.账单号 = bill.账单号 where bill.`用户卡号` = \'" + user.getCardId() +"\' order by 流水号 desc limit 20";
		
		ResultSet rs = sql.search(s);
		
		return rs;
		
	}
	
}
